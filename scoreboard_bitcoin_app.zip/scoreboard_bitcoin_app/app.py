from flask import Flask, render_template, request, redirect, url_for
from coinbase_commerce.client import Client
import os, json, hmac, hashlib

app = Flask(__name__)

API_KEY = 'Tu_API_KEY_de_Coinbase_Commerce'
# Asegúrate de reemplazar 'Tu_API_KEY_de_Coinbase_Commerce' con tu clave API real
# Puedes obtenerla desde tu cuenta de Coinbase Commerce
# https://commerce.coinbase.com/dashboard/settings/api_keys
client = Client(api_key=API_KEY)
WEBHOOK_SECRET = 'Tu_WEBHOOK_SECRET_de_Coinbase_Commerce'
# Asegúrate de reemplazar 'Tu_WEBHOOK_SECRET_de_Coinbase_Commerce' con tu secreto real
# Puedes obtenerlo desde tu cuenta de Coinbase Commerce
# https://commerce.coinbase.com/dashboard/settings/webhooks

SCORE_FILE = 'scores.json'
global_scores = {}

# Función para cargar puntuaciones desde archivo
def load_scores():
    global global_scores
    if os.path.exists(SCORE_FILE):
        with open(SCORE_FILE, 'r') as f:
            global_scores = json.load(f)

# Función para guardar puntuaciones en archivo
def save_scores():
    with open(SCORE_FILE, 'w') as f:
        json.dump(global_scores, f)

@app.route('/')
def index():
    return render_template('index.html', scores=global_scores)

@app.route('/pay', methods=['POST'])
def pay():
    user_id = request.form['user_id']
    charge = client.charge.create(
        name='Sube tu puntuación',
        description='Compra puntos para subir en el scoreboard',
        local_price={'amount': '1.00', 'currency': 'USD'},
        pricing_type='fixed_price',
        metadata={'user_id': user_id}
    )
    return redirect(charge.hosted_url)

@app.route('/webhook', methods=['POST'])
def webhook():
    payload = request.data
    signature = request.headers.get('X-CC-Webhook-Signature', '')

    try:
        hmac_obj = hmac.new(WEBHOOK_SECRET.encode(), payload, hashlib.sha256)
        expected_sig = hmac_obj.hexdigest()
        if not hmac.compare_digest(expected_sig, signature):
            return 'Invalid signature', 400

        data = json.loads(payload)
        event_type = data['event']['type']
        metadata = data['event']['data']['metadata']
        user_id = metadata.get('user_id')

        if event_type == 'charge:confirmed' and user_id:
            global_scores[user_id] = global_scores.get(user_id, 0) + 100
            save_scores()

        return 'ok', 200
    except Exception as e:
        return str(e), 500

if __name__ == '__main__':
    load_scores()
    app.run(debug=True)